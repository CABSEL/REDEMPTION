% REDEMPTION is written by Yang LIU(cosmicliuyang@gmail.com) 
% Copyright (C) 
% Last Update 30.07.2015

% The author accepts no liability for the quality of the information provided
% or for it being correct, complete or up to date. Liability claims against
% the author concerning either material or intellectual damage or other
% detrimental results resulting from the use or non-use of any information
% provided, including any information that is either incomplete or
% incorrect, will therefore be rejected.

p = pwd;
addpath(p)
addpath(fullfile(p,  'ensemble'))

% assuming redemption.m is in the  directory of ensemble

% %SPLINEFIT
% addpath(fullfile(p, '..', 'splinefit'))
% 
% % HYPERSPACE
% addpath(fullfile(p, '..', 'HYPERSPACE', 'Files'))
% 
% % eSS
% addpath(genpath(fullfile(p, '..', 'PUBLIC RELEASE SSm R2010A MATLAB7.5 and later', 'bin')))     
% addpath(genpath(fullfile(p, '..', 'PUBLIC RELEASE SSm R2010A MATLAB7.5 and later', 'local_solvers')))
% 
% % sundials
% addpath(genpath(fullfile(p, '..', 'sundials', 'sundialsTB')))
% startup_STB
% 
% % for importing SBML model
% addpath('/usr/local/lib')                                                       % for libsbml
% addpath(genpath(fullfile(p, '..', 'SBMLToolbox-4.1.0', 'toolbox')))             % for sbmltoolbox

%%
% % assuming redemption.m is in the PARENT directory of ensemble, as well as required
% % toolboxes
% 
% p = pwd;
% addpath(p)
% 
% %SPLINEFIT
% addpath(fullfile(p, 'splinefit'))
% 
% % HYPERSPACE
% addpath(fullfile(p, 'HYPERSPACE', 'Files'))
% 
% % eSS
% addpath(genpath(fullfile(p, 'PUBLIC RELEASE SSm R2010A MATLAB7.5 and later', 'bin')))     
% addpath(genpath(fullfile(p, 'PUBLIC RELEASE SSm R2010A MATLAB7.5 and later', 'local_solvers')))
% 
% % sundials
% addpath(genpath(fullfile(p, 'sundials', 'sundialsTB')))
% startup_STB
% 
% % for importing SBML model
% addpath('/usr/local/lib')                                                 % for libsbml
% addpath(genpath(fullfile(p, 'SBMLToolbox-4.1.0', 'toolbox')))             % for sbmltoolbox



%%
% close all;
% clear;
% clear global;
% clc;

gui
