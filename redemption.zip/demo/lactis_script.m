%Script interface of REDEMPTION to study glycolytic pathway in L. lactis.

% Model specification for powerlaw or lin-log kinetics

SBmodel.kineticsSelection = 'Lin-log kinetics';     % ['Power-law kinetics'|'Lin-log kinetics']

SBmodel.XUindex = [];
SBmodel.mI = 3;
% SBmodel.XinputIndex = [ 7 8 9 ];


SBmodel.S = [     1    -1     0     0     0     0     0     0     0
                  0     1    -1     0     0     0     0     0     0
                  0     0     2     1    -1     0     0     0     0
                 -1     0     0    -1     1    -1    -1     0     0
                  1     0     0     0     0     1     0    -1    -1
                  0     0     0     0     0     0     0     1     0];

SBmodel.ag = [    1     0  -500   500
                  1     1  -500   500
                  1     4  -500   500
                  1     7  -500   500
                  2     0  -500   500
                  2     1  -500   500
                  2     8  -500   500
                  3     0  -500   500
                  3     2  -500   500
                  3     9  -500   500
                  4     0  -500   500
                  4     4  -500   500
                  5     0  -500   500
                  5     3  -500   500
                  6     0  -500   500
                  6     2  -500   500
                  6     4  -500   500
                  6     9  -500   500
                  7     0  -500   500
                  7     4  -500   500
                  8     0  -500   500
                  8     2  -500   500
                  8     5  -500   500
                  9     0  -500   500
                  9     5  -500   500];
 



% % Model specification imported from SBML file
% SBmodel = SBMLImportModel('SBMLfileName');

% Selection of independent reaction subset (independent fluxes).
SBmodel.fluxesIndependent = [5 7 9];
% Selection of independent reaction subset is calculated by REDEMPTION
% automatically.
% SBmodel.fluxesIndependent = [];

% optimization over initial concentration.
SBmodel.X0_L = [];          % use time-series data
SBmodel.X0_U = [];          % use time-series data

% initialize model specification and options for pe and en.
[SBmodel, pe, en] = init_SBmodel(SBmodel);

% Load time-series data (.csv)
% prepare csv: each column represents one concentration species in the
% order of SBmodel.speciesID
w = importdata('demo//lactis_data.csv');
if(isfield(w, 'colheaders') )
    %         w.colheaders
    data.t = w.data(:,1)';
    data.x = w.data(:,2:end)';
else
    error('Incorrect column labels for each species. Follow the orders in SBmodel.speciesID ');
end


% smoothen time-series data using 6 pieces polynomials of degree 4
for i = 1:size(data.x, 1)
    data.pp(i) = splinefit(data.t, data.x(i,:), 6, 5);  % 6 is the number of pieces and 5-1=4 is the degree of piecewise-polynomials.
end
% initialize 
[SBmodel data] = init_data(SBmodel, data);


% select error type 
pe.problem.error_type_Selection = 'absolute';  % [absolute|relative]
% carry out parameter estimation
pe.objectiveFunctionIdx = 4;                           % 1.IPE; 2.IPE-ODE; 3.IFPE; 4.IFPE-ODE
pe.optimizerIdx = 1;                                   % 1. eSS; 2.genetic algorithm
[t_sim, x_sim, pe, SBmodel] = parameterEstimation(SBmodel, data, pe);
% plot time-series data and concentration predictions
plot(data.t, data.x(SBmodel.XODEindex, :), 'x', t_sim, x_sim);
xlabel('t');
ylabel('X_i');

% ensemble modeling
en.x0 = pe.xbest;
en.objectiveFunctionIdx = pe.objectiveFunctionIdx;
en.threshold = 0.75;                                % should be large than pe.fbest
en = ensembleGeneration(SBmodel, data, pe, en);

% visualize ensemble
x_ind = 13; 					% select x-axis
y_ind = 14;					% select y-axis

figure;
plot(en.parameterEnsemble(:,x_ind), en.parameterEnsemble(:,y_ind),'.b');
xlabel(en.parameterEnsembleID(x_ind));
ylabel(en.parameterEnsembleID(y_ind));

hold on
plot(en.p0(x_ind), en.p0(y_ind), 'o', 'MarkerEdgeColor', 'none', 'MarkerFaceColor', 'r', 'MarkerSize', 15);

